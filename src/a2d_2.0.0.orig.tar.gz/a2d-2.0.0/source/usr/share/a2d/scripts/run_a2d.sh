#!/bin/sh

python /usr/share/a2d/runscripts.py