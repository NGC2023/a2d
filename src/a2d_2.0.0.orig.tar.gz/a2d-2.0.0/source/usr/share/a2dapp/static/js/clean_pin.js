// Clean PIN input
function cancelAction() {
    window.location.href = "/login";
}

function clearPinFields() {
    document.getElementById("pinForm").reset();
}
