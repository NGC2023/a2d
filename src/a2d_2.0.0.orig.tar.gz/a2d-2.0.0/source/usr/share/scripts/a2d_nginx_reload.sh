#!/bin/bash

sudo systemctl reload nginx
