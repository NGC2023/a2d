#!/bin/bash

# This script removes a self-signed SSL certificate and key

sudo rm /etc/nginx/ssl/a2d-ssl.*
