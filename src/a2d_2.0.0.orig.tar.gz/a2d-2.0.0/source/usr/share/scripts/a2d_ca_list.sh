#!/bin/bash
sudo ls /etc/letsencrypt/live/ | grep -v "README"
